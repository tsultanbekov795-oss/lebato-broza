const STICKERS = ['🔥','😂','❤️','👍','😎','🚀','💯','👀','🫡','😈','👻','🧠','💪','🎉','✨','🍕','🐱','🐶','🦄','🐸','💀','🤙','😤','🤩'];
let token = localStorage.getItem('lb_token');
let user = null;
let pendingImages = [];
let pendingSticker = null;
let currentConv = null;
let pollTimer = null;

async function api(path, opts = {}) {
  const headers = opts.headers || {};
  if (token) headers['Authorization'] = 'Bearer ' + token;
  if (!(opts.body instanceof FormData) && opts.body && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }
  const res = await fetch(path, { ...opts, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Ошибка');
  return data;
}

function $(id) { return document.getElementById(id); }
function show(el) { if (el) el.classList.remove('hidden'); }
function hide(el) { if (el) el.classList.add('hidden'); }
function esc(t) { const d = document.createElement('div'); d.textContent = t || ''; return d.innerHTML; }
function timeAgo(ts) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return 'сейчас';
  if (s < 3600) return Math.floor(s / 60) + ' мин';
  if (s < 86400) return Math.floor(s / 3600) + ' ч';
  return Math.floor(s / 86400) + ' дн';
}

async function enter() {
  try {
    if (token) {
      try { user = await api('/api/me'); onReady(); return; }
      catch { localStorage.removeItem('lb_token'); token = null; }
    }
    const data = await api('/api/guest', { method: 'POST', body: '{}' });
    token = data.token;
    user = data.user;
    localStorage.setItem('lb_token', token);
    onReady();
  } catch (e) {
    console.error(e);
    $('posts-list').innerHTML = '<div class="empty"><div class="big">⚠️</div>Сервер недоступен.<br>Запусти: <code>node server/index.js</code></div>';
  }
}

function onReady() {
  updateUI();
  loadFeed();
  loadStories();
  loadStats();
  // auto-refresh feed every 5s so users see each other
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(() => {
    if (!$('view-feed').classList.contains('hidden')) loadFeed(true);
    loadStats();
  }, 5000);
}

function updateUI() {
  if (!user) return;
  $('side-avatar').src = user.avatar;
  $('side-name').textContent = user.displayName;
  $('compose-avatar').src = user.avatar;
}

const titles = {
  feed: ['Лента', 'общая лента · все пользователи'],
  stories: ['Истории', 'исчезают через 24 часа'],
  messages: ['Сообщения', 'личные чаты'],
  profile: ['Профиль', '']
};

function showView(name) {
  ['feed', 'stories', 'messages', 'profile'].forEach(v => {
    const el = $('view-' + v);
    if (el) el.classList.toggle('hidden', v !== name);
  });
  document.querySelectorAll('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.view === name));
  const t = titles[name] || ['', ''];
  $('view-title').textContent = t[0];
  $('view-sub').textContent = t[1];
  if (name === 'feed') { loadFeed(); loadStories(); }
  if (name === 'stories') loadStoriesFull();
  if (name === 'messages') loadConversations();
  if (name === 'profile') loadProfile();
  $('sidebar').classList.remove('mobile-open');
}

async function loadFeed(silent) {
  try {
    const posts = await api('/api/posts');
    renderPosts(posts);
  } catch (e) {
    if (!silent) $('posts-list').innerHTML = '<div class="empty"><div class="big">⚠️</div>' + esc(e.message) + '</div>';
  }
}

function renderPosts(posts) {
  const box = $('posts-list');
  if (!posts.length) {
    box.innerHTML = '<div class="empty"><div class="big">💬</div>Нет публикаций.<br>Будь первым!</div>';
    return;
  }
  box.innerHTML = posts.map(p => {
    const liked = p.likedByMe;
    const reposted = p.repostedByMe;
    const images = p.images?.length ? `<div class="post-imgs">${p.images.map(s => `<img src="${s}" onclick="openImage('${s}')">`).join('')}</div>` : '';
    const sticker = p.sticker ? `<div class="post-sticker">${p.sticker}</div>` : '';
    const repost = p.isRepost ? '<div class="repost-label">🔁 Репост</div>' : '';
    const comments = (p.comments || []).map(c => {
      const a = c.author || {};
      return `<div class="comment">
        <img src="${a.avatar || ''}">
        <div class="comment-bubble">
          <div class="who">${esc(a.displayName || '')}</div>
          <div class="txt">${c.sticker ? c.sticker : esc(c.text)}</div>
        </div>
      </div>`;
    }).join('');
    return `<article class="post">
      ${repost}
      <div class="post-head">
        <img src="${p.author?.avatar || ''}">
        <div><div class="author">${esc(p.author?.displayName || '')}</div></div>
        <span class="time">${timeAgo(p.createdAt)}</span>
      </div>
      ${p.text ? `<div class="post-body">${esc(p.text)}</div>` : ''}
      ${sticker}${images}
      <div class="post-bar">
        <button class="react-btn ${liked ? 'liked' : ''}" onclick="toggleLike('${p.id}', this)">
          <span class="heart">${liked ? '❤️' : '🤍'}</span> ${p.likesCount || p.likes?.length || ''}
        </button>
        <button class="react-btn ${reposted ? 'reposted' : ''}" onclick="toggleRepost('${p.id}')">🔁 ${p.repostsCount || p.reposts?.length || ''}</button>
        <button class="react-btn" onclick="toggleComments('${p.id}')">💬 ${p.commentsCount || p.comments?.length || ''}</button>
      </div>
      <div class="comments" id="comments-${p.id}" style="display:none">
        ${comments}
        <div class="add-cmt">
          <input id="c-input-${p.id}" placeholder="Комментарий..." onkeydown="if(event.key==='Enter')addComment('${p.id}')">
          <button onclick="addComment('${p.id}')">➤</button>
        </div>
      </div>
    </article>`;
  }).join('');
}

async function createPost() {
  const text = $('post-text').value.trim();
  if (!text && !pendingSticker && !pendingImages.length) { alert('Напиши что-нибудь'); return; }
  try {
    const fd = new FormData();
    fd.append('text', text);
    if (pendingSticker) fd.append('sticker', pendingSticker);
    if (pendingImages.length) fd.append('imagesBase64', JSON.stringify(pendingImages));
    await api('/api/posts', { method: 'POST', body: fd });
    $('post-text').value = '';
    pendingImages = []; pendingSticker = null;
    renderPreview(); hide($('stickers-panel'));
    loadFeed();
  } catch (e) { alert(e.message); }
}

window.toggleLike = async (id, btn) => {
  try {
    await api('/api/posts/' + id + '/like', { method: 'POST' });
    if (btn) {
      const heart = btn.querySelector('.heart');
      if (heart) { heart.classList.remove('heart'); void heart.offsetWidth; heart.classList.add('heart'); }
    }
    loadFeed();
  } catch (e) { alert(e.message); }
};

window.toggleRepost = async (id) => {
  try { await api('/api/posts/' + id + '/repost', { method: 'POST' }); loadFeed(); }
  catch (e) { alert(e.message); }
};

window.toggleComments = (id) => {
  const el = $('comments-' + id);
  if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none';
};

window.addComment = async (id) => {
  const input = $('c-input-' + id);
  const text = input?.value.trim();
  if (!text) return;
  try {
    await api('/api/posts/' + id + '/comments', { method: 'POST', body: JSON.stringify({ text }) });
    input.value = '';
    loadFeed();
    setTimeout(() => { const el = $('comments-' + id); if (el) el.style.display = 'block'; }, 50);
  } catch (e) { alert(e.message); }
};

function renderPreview() {
  $('preview-images').innerHTML = pendingImages.map((src, i) =>
    `<div style="position:relative"><img src="${src}"><button onclick="pendingImages.splice(${i},1);renderPreview()" style="position:absolute;top:-4px;right:-4px;background:#e53935;border:none;color:#fff;width:18px;height:18px;border-radius:50%;cursor:pointer;font-size:11px">×</button></div>`
  ).join('');
}

async function loadStories() {
  try {
    const groups = await api('/api/stories');
    const bar = $('stories-bar');
    if (!groups.length) { bar.innerHTML = ''; return; }
    bar.innerHTML = groups.map(g => `
      <div class="story-item" onclick="alert('История от ${esc(g.user.displayName)}')">
        <img src="${g.stories[0]?.image || g.user.avatar}"><span>${esc(g.user.displayName)}</span>
      </div>`).join('');
  } catch {}
}

async function loadStoriesFull() {
  try {
    const groups = await api('/api/stories');
    const el = $('stories-full');
    if (!groups.length) { el.innerHTML = '<div class="empty"><div class="big">◎</div>Нет историй</div>'; return; }
    el.innerHTML = groups.map(g => `
      <div class="story-item"><img src="${g.stories[0]?.image || g.user.avatar}" style="width:72px;height:72px"><span>${esc(g.user.displayName)}</span></div>
    `).join('');
  } catch {}
}

async function loadConversations() {
  try {
    const list = await api('/api/conversations');
    const el = $('conversations');
    if (!list.length) {
      el.innerHTML = '<div class="empty" style="padding:30px"><div class="big">✉</div>Нет чатов<br><span style="font-size:0.85rem">Найди человека через поиск</span></div>';
      return;
    }
    el.innerHTML = list.map(c => `
      <div class="conv-item ${c.id === currentConv ? 'active' : ''}" onclick="openChat('${c.id}')">
        <img src="${c.other?.avatar || ''}">
        <div><div class="cname">${esc(c.other?.displayName || '')}</div>
        <div class="cprev">${c.lastMessage ? (c.lastMessage.fromMe ? 'Вы: ' : '') + esc(c.lastMessage.text || c.lastMessage.sticker || '') : ''}</div></div>
      </div>`).join('');
  } catch {}
}

window.openChat = async (id) => {
  currentConv = id;
  try {
    const msgs = await api('/api/conversations/' + id + '/messages');
    const convs = await api('/api/conversations');
    const conv = convs.find(c => c.id === id);
    const other = conv?.other;
    $('chat-area').innerHTML = `
      <div class="chat-head">
        <img src="${other?.avatar || ''}" style="width:40px;height:40px;border-radius:50%">
        <div><div style="font-weight:500">${esc(other?.displayName || '')}</div>
        <div style="font-size:0.8rem;color:var(--muted)"><span class="online-dot"></span> в сети</div></div>
      </div>
      <div class="chat-msgs" id="chat-msgs">${msgs.map(m =>
        `<div class="bubble ${m.fromMe ? 'out' : 'in'}">${m.sticker ? `<span style="font-size:1.8rem">${m.sticker}</span>` : esc(m.text)}</div>`
      ).join('')}</div>
      <div class="chat-compose">
        <button class="icon-btn" onclick="sendMsgSticker()">😊</button>
        <input id="msg-input" placeholder="Сообщение..." onkeydown="if(event.key==='Enter')sendMsg()">
        <button class="send-btn" onclick="sendMsg()" style="padding:8px 14px">➤</button>
      </div>`;
    const box = $('chat-msgs'); if (box) box.scrollTop = box.scrollHeight;
    loadConversations();
  } catch (e) { alert(e.message); }
};

window.sendMsg = async () => {
  const input = $('msg-input');
  const text = input?.value.trim();
  if (!text || !currentConv) return;
  try {
    await api('/api/conversations/' + currentConv + '/messages', { method: 'POST', body: JSON.stringify({ text }) });
    input.value = '';
    openChat(currentConv);
  } catch (e) { alert(e.message); }
};

window.sendMsgSticker = async () => {
  const s = prompt('Стикер:\n' + STICKERS.join(' '));
  if (!s || !currentConv) return;
  try {
    await api('/api/conversations/' + currentConv + '/messages', { method: 'POST', body: JSON.stringify({ sticker: s.trim().slice(0, 4) }) });
    openChat(currentConv);
  } catch (e) { alert(e.message); }
};

window.startChatWith = async (userId) => {
  try {
    const conv = await api('/api/conversations', { method: 'POST', body: JSON.stringify({ userId }) });
    showView('messages');
    openChat(conv.id);
  } catch (e) { alert(e.message); }
};

async function doSearch() {
  const q = ($('search-input').value || '').trim();
  const box = $('search-results');
  if (!q) { hide(box); return; }
  try {
    const data = await api('/api/search?q=' + encodeURIComponent(q));
    let html = '';
    data.users.forEach(u => {
      html += `<div class="search-row" onclick="startChatWith('${u.id}');hide($('search-results'));$('search-input').value=''">
        <img src="${u.avatar}"><b>${esc(u.displayName)}</b></div>`;
    });
    if (!html) html = '<div style="padding:14px;color:var(--muted)">Ничего не найдено</div>';
    box.innerHTML = html; show(box);
  } catch {}
}

function loadProfile() {
  if (!user) return;
  $('profile-avatar').src = user.avatar;
  $('profile-name').textContent = user.displayName;
  $('profile-bio').textContent = user.bio || 'Расскажи о себе';
}

async function loadStats() {
  try {
    const s = await api('/api/stats');
    $('stat-users').textContent = s.users + ' польз.';
  } catch {}
}

window.openImage = (src) => { $('full-img').src = src; show($('image-viewer')); };

document.addEventListener('DOMContentLoaded', () => {
  const theme = localStorage.getItem('lb_tg_theme') || 'dark';
  document.documentElement.setAttribute('data-theme', theme);
  $('theme-btn').textContent = theme === 'dark' ? '🌙' : '☀️';
  $('theme-btn').onclick = () => {
    const n = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', n);
    localStorage.setItem('lb_tg_theme', n);
    $('theme-btn').textContent = n === 'dark' ? '🌙' : '☀️';
  };

  document.querySelectorAll('.nav-item[data-view]').forEach(b => b.onclick = () => showView(b.dataset.view));
  $('menu-btn').onclick = () => $('sidebar').classList.toggle('mobile-open');
  $('publish-btn').onclick = createPost;
  $('image-input').onchange = e => {
    Array.from(e.target.files).forEach(f => {
      const r = new FileReader();
      r.onload = ev => { pendingImages.push(ev.target.result); renderPreview(); };
      r.readAsDataURL(f);
    });
    e.target.value = '';
  };
  $('sticker-toggle').onclick = () => {
    const p = $('stickers-panel');
    p.classList.toggle('hidden');
    if (!p.innerHTML) p.innerHTML = STICKERS.map(s =>
      `<button class="sticker-btn" onclick="pendingSticker='${s}';$('post-text').value=($('post-text').value+' ${s}').trim();hide($('stickers-panel'))">${s}</button>`
    ).join('');
  };
  $('story-image').onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    const fd = new FormData(); fd.append('image', f);
    try { await api('/api/stories', { method: 'POST', body: fd }); loadStories(); loadStoriesFull(); alert('История добавлена!'); }
    catch (err) { alert(err.message); }
    e.target.value = '';
  };

  let st;
  $('search-input').oninput = () => { clearTimeout(st); st = setTimeout(doSearch, 250); };
  document.addEventListener('click', e => {
    if (!$('search-input').parentElement.contains(e.target)) hide($('search-results'));
  });

  $('edit-profile-btn').onclick = () => {
    $('edit-name').value = user.displayName;
    $('edit-bio').value = user.bio || '';
    show($('profile-modal'));
  };
  $('close-profile').onclick = () => hide($('profile-modal'));
  $('save-profile').onclick = async () => {
    try {
      const fd = new FormData();
      fd.append('displayName', $('edit-name').value.trim() || 'Гость');
      fd.append('bio', $('edit-bio').value.trim());
      const f = $('edit-avatar').files[0];
      if (f) fd.append('avatar', f);
      user = await api('/api/me', { method: 'PATCH', body: fd });
      updateUI(); loadProfile(); hide($('profile-modal'));
    } catch (e) { alert(e.message); }
  };
  $('close-img').onclick = () => hide($('image-viewer'));
  $('image-viewer').onclick = e => { if (e.target.id === 'image-viewer') hide($('image-viewer')); };

  enter();
});
